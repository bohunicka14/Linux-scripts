#!/bin/bash

meno=$1
odpoved=$2
sekundy=$3

if [ "$odpoved" = ano ]
then
sleep $sekundy
echo ${meno}, zadal si cas $sekundy a chces ho vykonat.
else
if [ "$odpoved" = nie ]
then
echo ${meno}, zadal si cas $sekundy a nechces ho vykonat.
fi
fi
